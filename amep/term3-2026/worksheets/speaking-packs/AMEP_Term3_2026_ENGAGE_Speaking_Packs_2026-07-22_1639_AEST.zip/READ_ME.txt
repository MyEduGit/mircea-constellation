AMEP TERM 3 2026 — ENGAGING SPEAKING PACKS (CP123E3 & CP123E4)
Packaged: 22 July 2026, 4:39 PM AEST

Talking/pair games for the mixed Cert I/II/III evening class. Each file is
ONE Word document with a TABLE OF CONTENTS (page 1) and PAGE NUMBERS in
every footer, so students at any level can find where the class is.
Different games in each genre — no repetition.

FOUR COMBINED DOCUMENTS
-----------------------
1. ENGAGE_Tour_Melbourne_and_West_COMBINED.docx        (Cert II, Task A "free things to do")
     Games: Class Mingle - Information Gap - Role-play
     Contains: "The West for Free" (PRACTICE, before Week 5) + "Melbourne for Free" (REAL, after Week 5) + 2 Cert III grammar sheets

2. ENGAGE_FirstAid_Cut_and_Burn_COMBINED.docx          (Cert II, Task C first aid)
     Games: Sequencing Race - Information Gap - First-Aider Role-play
     Contains: "Treating a Minor Burn" (PRACTICE, before Week 7) + "Treating a Cut" (REAL, after Week 7) + 2 grammar sheets

3. ENGAGE_CertIII_Health_Eating_and_Sleep_COMBINED.docx (Cert III, Task A health talk)
     Games: Class Survey - Rank & Talk - Give-Advice Role-play
     Contains: "Sleeping for Good Health" (PRACTICE, before Week 5) + "Eating for Good Health" (REAL, after Week 5) + 2 grammar sheets

4. ENGAGE_CertIII_Instructions_Lifting_and_Mopping_COMBINED.docx (Cert III, Task C instructions)
     Games: "Do It!" Action Game - Spot the Mistake - Teach-a-New-Worker Role-play
     Contains: "Mopping a Floor Safely" (PRACTICE, before Week 7) + "Safe Lifting" (REAL, after Week 7) + 2 grammar sheets

HOW TO USE
----------
- PRACTICE (parallel) texts: use BEFORE the assessment. REAL texts: use AFTER (consolidation).
- Grammar sheets are OPTIONAL, for strong Cert III students only.
- TABLE OF CONTENTS: page numbers fill in automatically when you open in Word.
  If they show blank, click the list and press F9 (printing also updates them).

ALL FACTS CHECKED (July 2026): City Circle tram still free; adult sleep 7-9 hrs
(Sleep Health Foundation); burn first aid (Better Health Channel); eating/lifting
are the official Commonwealth assessment texts.
