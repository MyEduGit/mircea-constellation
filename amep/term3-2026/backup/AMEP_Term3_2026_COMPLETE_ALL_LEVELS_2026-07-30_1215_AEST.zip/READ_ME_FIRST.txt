AMEP TERM 3 2026 — COMPLETE STUDENT MATERIALS, ALL THREE LEVELS
Packaged: 30 July 2026, 12:15 PM AEST   Class CP123E3 & CP123E4

weekly/  ......... 10 tiered worksheets (Weeks 1-10)
speaking-packs/ .. 6 combined talking/pair-game documents

Every Word file has a TABLE OF CONTENTS (page 1) and PAGE NUMBERS in the
footer, so mixed-level students can always find where the class is.

SPEAKING PACKS BY LEVEL
  CERT I   ENGAGE_CertI_Travel_Roleplay_COMBINED.docx      (VU23501 Task A)
           ENGAGE_CertI_Ordering_Roleplay_COMBINED.docx    (VU23501 Task B)
           Games: Find Your Partner - Roll & Change (dice) - Role-play + observer
  CERT II  ENGAGE_Tour_Melbourne_and_West_COMBINED.docx     (VU23520 Task A)
           ENGAGE_FirstAid_Cut_and_Burn_COMBINED.docx       (VU23520 Task C)
  CERT III ENGAGE_CertIII_Health_Eating_and_Sleep_COMBINED.docx   (VU23525 Task A)
           ENGAGE_CertIII_Instructions_Lifting_and_Mopping_COMBINED.docx (Task C)

EACH PACK CONTAINS a PRACTICE version (parallel topic - safe to use BEFORE
the assessment) and the CLASS-TOPIC version (rehearsal / after-assessment
revision), plus optional Cert III grammar sheets where relevant.

FACTS CHECKED JULY 2026: Melbourne fares HALF PRICE 1 Jun 2026 - 1 Jan 2027
(daily cap $5.70, concession $2.85); under-18s free with a Youth Myki; one
metro fare zone; City Circle tram free; adult sleep 7-9 hrs (Sleep Health
Foundation); burn first aid (Better Health Channel). Cafe/pizza menu prices
are CLASS EXAMPLES, not a real shop's prices.

Master copy: GitHub MyEduGit/mircea-constellation, PR #84,
amep/term3-2026/worksheets/
