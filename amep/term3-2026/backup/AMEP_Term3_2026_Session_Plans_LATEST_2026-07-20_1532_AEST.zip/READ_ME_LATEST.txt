LATEST SESSION/LESSON PLAN SET — TERM 3, 2026 — TEN WEEKS
Packaged: 20 July 2026, 3:32 PM AEST

This is the definitive, verified set of ten AMEP Daily Lesson Plans for
CP123E3 & CP123E4 (mixed Cert I/II/III EAL evening class), Term 3 2026,
13 July - 16 September, Monday + Wednesday evenings.

- Built on the official AMEP evening-class session-plan template
  (two-table structure, US Letter landscape, original styling).
- Week 7 is the corrected v2 (Cert III Task C cited by official title).
- Units confirmed in aXcelerate: VU23500/VU23501 (Cert I),
  VU22358/VU23520 (Cert II), VU22384/VU23525 (Cert III).
- All assessment tasks verified against official assessor guides;
  both Cert III recordings verified against official transcripts.

Master copies: GitHub MyEduGit/mircea-constellation, PR #84,
amep/term3-2026/session-plans/ (with SHA-256 manifest in Google Drive:
AMEP - TERM 3 - 2026 - Session Plans/TERM3_2026_BACKUP_MANIFEST.md).
