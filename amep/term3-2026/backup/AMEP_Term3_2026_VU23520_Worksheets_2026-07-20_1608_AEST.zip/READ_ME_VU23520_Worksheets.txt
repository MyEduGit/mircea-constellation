VU23520 WORKSHEET SET (CERT II STRAND) — TERM 3 2026 (CP123E3 & CP123E4)
Packaged: 20 July 2026, 4:08 PM AEST

PRE-ASSESSMENT PRACTICE (parallel original texts — safe before Weeks 5/7):
  PARALLEL_The_West_for_Free_WORKSHEET.docx        (mirrors Task A)
  PARALLEL_Treating_a_Minor_Burn_WORKSHEET.docx    (mirrors Task C)

POST-ASSESSMENT CONSOLIDATION (real assessment texts — Weeks 9-10 revision):
  VU23520_TaskA_Melbourne_for_free_WORKSHEET.docx
  VU23520_TaskC_First_aid_WORKSHEET.docx

Do not use the two real-text worksheets before the Week 5 / Week 7
assessments. Parts A-C all levels; D-H Cert II/III extension; teacher
answer key on the final page of each - remove before copying.

Master copies: GitHub MyEduGit/mircea-constellation, PR #84,
amep/term3-2026/worksheets/
