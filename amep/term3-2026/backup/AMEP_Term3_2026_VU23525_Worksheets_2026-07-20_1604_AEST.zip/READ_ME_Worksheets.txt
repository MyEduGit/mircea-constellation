VU23525 WORKSHEET SET — TERM 3 2026 (CP123E3 & CP123E4)
Packaged: 20 July 2026, 4:04 PM AEST

Four mixed-level worksheets (Parts A-C all levels; D-H Cert III extension;
teacher answer key on the final page of each — remove before copying):

PRE-ASSESSMENT PRACTICE (parallel original texts — safe before Weeks 5/7):
  PARALLEL_Sleeping_for_good_health_WORKSHEET.docx   (mirrors Task A)
  PARALLEL_Mopping_a_floor_safely_WORKSHEET.docx     (mirrors Task C)

POST-ASSESSMENT CONSOLIDATION (real assessment texts — Weeks 9-10 revision):
  VU23525_TaskA_Eating_for_good_health_WORKSHEET.docx
  VU23525_TaskC_Safe_Lifting_WORKSHEET.docx

Do not use the two real-text worksheets before the Week 5 / Week 7
assessments - the assessor guide requires preparation with SIMILAR
(not identical) texts.

Master copies: GitHub MyEduGit/mircea-constellation, PR #84,
amep/term3-2026/worksheets/
